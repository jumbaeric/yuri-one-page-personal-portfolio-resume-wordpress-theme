=== Yuri Portfolio Custom Post Type ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://jumbaeric.co.ke
Tags: custom post type, cpt, portfolio, testimonials, gallery
Requires at least: 3.0.1
Tested up to: 6.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin adds portfolio, testimonials, services custom post type, and custom meta fields, this enables freelancers to manage their portfolios, add gallery images to portolio, services, and testimonials

== Description ==

This plugin adds portfolio, testimonials, services custom post type, and custom meta fields, this enables freelancers to manage their portfolios, add gallery images to portolio, services, and testimonials

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `yuri-portfolio-cpt.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates
